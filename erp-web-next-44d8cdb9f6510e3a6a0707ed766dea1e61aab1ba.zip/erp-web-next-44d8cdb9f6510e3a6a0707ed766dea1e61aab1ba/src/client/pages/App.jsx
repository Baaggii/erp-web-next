export default function App() {
  return (
    <div className="p-6 text-xl font-bold text-green-700">
      MM ERP Final Scaffold ✅
    </div>
  )
}