export const GLOBAL_COMPANY_ID = 0;
