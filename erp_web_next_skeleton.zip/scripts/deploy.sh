#!/usr/bin/env bash
npm ci --no-progress
npm run build -- --base=/erp/
